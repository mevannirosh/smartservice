
      
      // Your web app's Firebase configuration
var l,lg;
  var firebaseConfig = {
apiKey: "AIzaSyBF-eQi3q_abScOALub4cAOUnnh2Hc_sYc",
    authDomain: "smartmobilevehicle.firebaseapp.com",
    databaseURL: "https://smartmobilevehicle.firebaseio.com",
    projectId: "smartmobilevehicle",
    storageBucket: "smartmobilevehicle.appspot.com",
    messagingSenderId: "71863870996",
    appId: "1:71863870996:web:bb0ee7067d85f18484e901",
    measurementId: "G-68F6P3863P"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
firebase.analytics();
var database = firebase.database();
firebase.auth().onAuthStateChanged(function(user) {
    if (user) {

    var companyid = firebase.auth().currentUser;
   
    if(companyid["uid"]=="fQdekyyeDqcPoURYEWvwT0rYVi43")
    {
      window.location.href = "suvasariyaDashboard.html";
    }
    else if(companyid["uid"]=="btwm3mgGrUXPEz0mwWyEtMuUZfm1")
    {
        window.location.href = "adminDashboard.html";
    }
    else
    {
      window.location.href = "insuaranceDashboard.html";
    }
    } else {

    }
});
function loadError()
{

        $('#myError').modal('show');

}
var input = document.getElementById("password");
input.addEventListener("keyup", function(event) {
  if (event.keyCode === 13) {
   login();
  }
});
function login() {
    // alert("sd");
    var username = document.getElementById("uname").value;
    var password = document.getElementById("password").value;
    var message=document.getElementById("errorMessage");
    firebase.auth().signInWithEmailAndPassword(username, password).catch(function(error) {
        // Handle Errors here.
        var errorCode = error.code;
        var errorMessage = error.message;
         message.innerHTML=errorMessage;
        
        loadError()
        // ...
    });
}
// googleSignIn();

function googleSignIn()
{
    var provider = new firebase.auth.GoogleAuthProvider();
  firebase.auth().signInWithPopup(provider).then(function(result) {
  // This gives you a Google Access Token. You can use it to access the Google API.
  var token = result.credential.accessToken;
  // The signed-in user info.
  var user = result.user;
 //alert(user);
  // ...
}).catch(function(error) {
  // Handle Errors here.
  var errorCode = error.code;
  var errorMessage = error.message;
  // The email of the user's account used.
  var email = error.email;
  // The firebase.auth.AuthCredential type that was used.
  var credential = error.credential;
  // ...
});
}

function facebookSignIn()
{
    var provider = new firebase.auth.FacebookAuthProvider();
    firebase.auth().signInWithPopup(provider).then(function(result) {
  // This gives you a Google Access Token. You can use it to access the Google API.
  var token = result.credential.accessToken;
  // The signed-in user info.
  var user = result.user;
  // ...
}).catch(function(error) {
  // Handle Errors here.
  var errorCode = error.code;
  var errorMessage = error.message;
  // The email of the user's account used.
  var email = error.email;
  // The firebase.auth.AuthCredential type that was used.
  var credential = error.credential;
  // ...
});
}
// function onSignIn(googleUser) {
//   var profile = googleUser.getBasicProfile();
//   console.log('ID: ' + profile.getId()); // Do not send to your backend! Use an ID token instead.
//   console.log('Name: ' + profile.getName());
//   console.log('Image URL: ' + profile.getImageUrl());
//   console.log('Email: ' + profile.getEmail()); // This is null if the 'email' scope is not present.
// }

