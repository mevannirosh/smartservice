
      
      // Your web app's Firebase configuration
var l,lg;
  var firebaseConfig = {
apiKey: "AIzaSyBF-eQi3q_abScOALub4cAOUnnh2Hc_sYc",
    authDomain: "smartmobilevehicle.firebaseapp.com",
    databaseURL: "https://smartmobilevehicle.firebaseio.com",
    projectId: "smartmobilevehicle",
    storageBucket: "smartmobilevehicle.appspot.com",
    messagingSenderId: "71863870996",
    appId: "1:71863870996:web:bb0ee7067d85f18484e901",
    measurementId: "G-68F6P3863P"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
firebase.analytics();
var database = firebase.database();

 var url_string = window.location.href; //window.location.href
var url = new URL(url_string);
var maploc = url.searchParams.get("mapid");
viewLocation();

 
 var map;
      function initMap() {
           var uluru = {
        lat: Number(l),
        lng: Number(lg)
    };
    map = new google.maps.Map(
        document.getElementById('map'), {
            zoom: 10,
            center: uluru
        });
    marker = new google.maps.Marker({
        position: uluru,
        map: map
    });
//loadMapAdditional();
      }
      function viewLocation() {
          alert(maploc);
    var leadsRef = database.ref('City');
    leadsRef.orderByChild("uid").on('value', function(snapshot) {
         alert(JSON.stringify(snapshot)+"df");
        snapshot.forEach(function(childSnapshot) {
            
             if(childSnapshot.val().uid === maploc)
             {
            
            l = childSnapshot.val().latitude;
            lg = childSnapshot.val().longtitude;
            // alert("s");
             loadMapAdditional();
            moveMarker();
            //LoadLocation();

}
           
             

        });
    });

}
      
//loadMapAdditional();
function loadMapAdditional()
{
   markerA = new google.maps.Marker({
        position: {
            lat: Number(l),
            lng: Number(lg)
        },
        map: map,
        icon: {
            url: 'https://fourssh.net/pixel/img/Circle-iconre.png'
        },
        title: "Marker A"
    });

    // 3. Put second marker in Bogota
    markerB = new google.maps.Marker({
        position: {
            lat: Number(l),
            lng: Number(lg)
        },
        map: map,
        icon: {
            url: 'https://fourssh.net/pixel/img/Circle-iconre.png'
        },
        title: "Marker B"
    });
    
    
    // var distanceInMeters = google.maps.geometry.spherical.computeDistanceBetween(
    //     markerA.getPosition(),
    //     markerB.getPosition()
    // );
    // var endDate = new Date();
       
    // var seconds = (endDate.getTime() - starttime.getTime()) / 1000;
    //  //alert((distanceInMeters*0.001).toFixed(2)/seconds*3600);
    // document.getElementById("des").innerHTML = (distanceInMeters * 0.001).toFixed(3);
    // document.getElementById("myspeed").innerHTML = ((distanceInMeters * 0.001) / seconds * 3600).toFixed(2);
    // var d = new Date(); // for now
    // d.getHours(); // => 9
    // d.getMinutes(); // =>  30
    // d.getSeconds();
    // // alert("total time"+seconds);
    // // alert("gaper time"+destinationtimegap);
    // // alert("diff time"+(seconds-destinationtimegap));
    // var diftime=seconds-destinationtimegap;
    // //document.getElementById("myavgspeed").innerHTML=(((distanceInMeters * 0.001)-destinationgap)/diftime* 3600).toFixed(2);
    // destinationtimegap=seconds;
    
    // destinationtimegap=seconds;
    // //alert(destinationtimegap);
    //  dist+=Math.abs(prevdist-(distanceInMeters * 0.001));
    // prevdist=(distanceInMeters * 0.001);
    // //alert("dfg"+dist);
    //  document.getElementById("des").innerHTML = (dist).toFixed(3);
    //  document.getElementById("myspeed").innerHTML = ((dist) / seconds * 3600).toFixed(2);
    //  document.getElementById("myavgspeed").innerHTML=((dist-destinationgap)/diftime* 3600).toFixed(2);
    //  destinationgap=(dist);
    // document.getElementById("currentSLocationTime").innerHTML = ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2) + ":" + ("0" + d.getSeconds()).slice(-2);
    // document.getElementById("currentDLocationTime").innerHTML = ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2) + ":" + ("0" + d.getSeconds()).slice(-2);
    // document.getElementById("currentLocationTime").innerHTML = ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2) + ":" + ("0" + d.getSeconds()).slice(-2);
    // document.getElementById("currentALocationTime").innerHTML = ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2) + ":" + ("0" + d.getSeconds()).slice(-2);
}

function moveMarker() {
    
    //delayed so you can see it move
    setTimeout( function(){ 
        //alert(l);
        marker.setPosition( new google.maps.LatLng( l, lg ) );
        map.panTo( new google.maps.LatLng(  l, lg ) );
        
    }, 10 );

};