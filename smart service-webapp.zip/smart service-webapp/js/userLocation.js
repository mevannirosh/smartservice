// Your web app's Firebase configuration

var companyid;

  var firebaseConfig = {
apiKey: "AIzaSyBF-eQi3q_abScOALub4cAOUnnh2Hc_sYc",
    authDomain: "smartmobilevehicle.firebaseapp.com",
    databaseURL: "https://smartmobilevehicle.firebaseio.com",
    projectId: "smartmobilevehicle",
    storageBucket: "smartmobilevehicle.appspot.com",
    messagingSenderId: "71863870996",
    appId: "1:71863870996:web:bb0ee7067d85f18484e901",
    measurementId: "G-68F6P3863P"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
firebase.analytics();
var database = firebase.database();
firebase.auth().onAuthStateChanged(function(user) {
  if (user) {
     
         companyid = firebase.auth().currentUser;
 
    //     var leadsRef = database.ref('userDetails/');
    //   alert("my uid "+users["uid"]);
    // leadsRef.orderByChild("uid").once('value', function(snapshot) {  
    //     snapshot.forEach(function(childSnapshot) {
    //         alert(JSON.stringify(childSnapshot));
    //     if(childSnapshot.val().uid==users["uid"])
    //     {
    //         alert("sad");
    //         companyid=childSnapshot.val().companyId;
    //     }
        
    //     });   
    // });
  } else {
      window.location.href = "index.html";
  }
});
viewLocationOne();
function viewLocationOne() {
    // var companyid = firebase.auth().currentUser;
    // alert(companyid["uid"]);
     var leadsRef = database.ref('userDetails/');
    leadsRef.orderByChild("uid").once('value', function(snapshot) {
       
        var tbodyy=document.getElementById("tablecontent");
        snapshot.forEach(function(childSnapshot) {
           
             if(childSnapshot.val().companyId==companyid["uid"] && childSnapshot.val().status==1)
        {
            var tr = document.createElement("tr");
            var td1=document.createElement("td");
            var address= document.createTextNode(childSnapshot.val().address);
            td1.appendChild(address);
            tr.appendChild(td1);
            var td2=document.createElement("td");
            var email= document.createTextNode(childSnapshot.val().email);
            td2.appendChild(email);
            tr.appendChild(td2);
            // var td3=document.createElement("td");
            // var emergencyContact= document.createTextNode(childSnapshot.val().emergencyContact);
            // td3.appendChild(emergencyContact);
            // tr.appendChild(td3);
            var td4=document.createElement("td");
            var fullName= document.createTextNode(childSnapshot.val().fullName);
            td4.appendChild(fullName);
            tr.appendChild(td4);
            // var td5=document.createElement("td");
            // var insueranceCompany= document.createTextNode(childSnapshot.val().insueranceCompany);
            // td5.appendChild(insueranceCompany);
            // tr.appendChild(td5);
            var td6=document.createElement("td");
            var mobile= document.createTextNode(childSnapshot.val().mobile);
            td6.appendChild(mobile);
            tr.appendChild(td6);
            var td7=document.createElement("td");
            var nic= document.createTextNode(childSnapshot.val().nic);
            td7.appendChild(nic);
            tr.appendChild(td7);  
            var td8=document.createElement("td");
            var vehicleNumber= document.createTextNode(childSnapshot.val().vehicleNumber);
            td8.appendChild(vehicleNumber);
            tr.appendChild(td8);
            tbodyy.appendChild(tr);
            
             var td9=document.createElement("td");
             var an=document.createElement("a");
             an.setAttribute("href","viewmap.html?mapid="+childSnapshot.val().uid);
            var Link= document.createTextNode("View location");
            an.appendChild(Link);
            td9.appendChild(an);
            tr.appendChild(td9);
            tbodyy.appendChild(tr);
        }

        });
    });

}