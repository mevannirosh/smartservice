var firebaseConfig = {
apiKey: "AIzaSyBF-eQi3q_abScOALub4cAOUnnh2Hc_sYc",
    authDomain: "smartmobilevehicle.firebaseapp.com",
    databaseURL: "https://smartmobilevehicle.firebaseio.com",
    projectId: "smartmobilevehicle",
    storageBucket: "smartmobilevehicle.appspot.com",
    messagingSenderId: "71863870996",
    appId: "1:71863870996:web:bb0ee7067d85f18484e901",
    measurementId: "G-68F6P3863P"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
firebase.analytics();


var database = firebase.database();

  var database = firebase.database();
  
  firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
        
         
    var name= document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var user = firebase.auth().currentUser;
    
    firebase.database().ref('InsuaranceCompany/' + user["uid"]).set({
    CompName: name,
    email: email,
    UID: user["uid"]
    
  });
    }
    else{}
    });

function signup() {
    
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;
    
    firebase.auth().createUserWithEmailAndPassword(email, password).then(function(){
        alert("User created");
        
    }).catch(function(error) {
  // Handle Errors here.
  var errorCode = error.code;
  var errorMessage = error.message;
  // ...
});
    
}







(function ($) {
    "use strict";

    
    /*==================================================================
    [ Validate ]*/
    var input = $('.validate-input .input100');

    $('.validate-form').on('submit',function(){
        var check = true;

        for(var i=0; i<input.length; i++) {
            if(validate(input[i]) == false){
                showValidate(input[i]);
                check=false;
            }
        }

        return check;
    });


    $('.validate-form .input100').each(function(){
        $(this).focus(function(){
           hideValidate(this);
        });
    });

    function validate (input) {
        if($(input).attr('type') == 'email' || $(input).attr('name') == 'email') {
            if($(input).val().trim().match(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/) == null) {
                return false;
            }
        }
        else {
            if($(input).val().trim() == ''){
                return false;
            }
        }
    }

    function showValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).addClass('alert-validate');
    }

    function hideValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).removeClass('alert-validate');
    }
    
    

})(jQuery);