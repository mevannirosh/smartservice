// Your web app's Firebase configuration

var companyid;

  var firebaseConfig = {
apiKey: "AIzaSyBF-eQi3q_abScOALub4cAOUnnh2Hc_sYc",
    authDomain: "smartmobilevehicle.firebaseapp.com",
    databaseURL: "https://smartmobilevehicle.firebaseio.com",
    projectId: "smartmobilevehicle",
    storageBucket: "smartmobilevehicle.appspot.com",
    messagingSenderId: "71863870996",
    appId: "1:71863870996:web:bb0ee7067d85f18484e901",
    measurementId: "G-68F6P3863P"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
firebase.analytics();
var database = firebase.database();
firebase.auth().onAuthStateChanged(function(user) {
  if (user) {
     
         companyid = firebase.auth().currentUser;
 
    //     var leadsRef = database.ref('userDetails/');
    //   alert("my uid "+users["uid"]);
    // leadsRef.orderByChild("uid").once('value', function(snapshot) {  
    //     snapshot.forEach(function(childSnapshot) {
    //         alert(JSON.stringify(childSnapshot));
    //     if(childSnapshot.val().uid==users["uid"])
    //     {
    //         alert("sad");
    //         companyid=childSnapshot.val().companyId;
    //     }
        
    //     });   
    // });
  } else {
      window.location.href = "index.html";
  }
});
viewLocationOne();
function viewLocationOne() {
    var name;
     var leadsRef = database.ref('reviews/');
    leadsRef.orderByChild("machanicUid").once('value', function(snapshot) {
       
        var tbodyy=document.getElementById("tablecontent");
        snapshot.forEach(function(childSnapshot) {

           var mecid=childSnapshot.val().machanicUid;
           var refuser=database.ref('userDetails/');
           refuser.orderByChild("uid").once('value', function(snapshot){
            snapshot.forEach(function(childSnapshot){
                if(mecid==childSnapshot.val().uid)
                {
                    name=childSnapshot.val().fullName;
                    
                }
            });
            
         
            var tr = document.createElement("tr");
            var td1=document.createElement("td");
            var mecname= document.createTextNode(name);
            td1.appendChild(mecname);
            tr.appendChild(td1);
            var td2=document.createElement("td");
            var status= document.createTextNode(childSnapshot.val().machanicStatus);
            td2.appendChild(status);
            tr.appendChild(td2);
            var td3=document.createElement("td");
            var value= document.createTextNode(childSnapshot.val().machanicValue);
            td3.appendChild(value);
            tr.appendChild(td3);
            
            tbodyy.appendChild(tr);
        
            });
        });
    });

}